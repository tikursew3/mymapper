<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> FruitMapper </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
button 
{   
       background-color: #4CAF50;   
       width: 100%;  
       color: orange;   
       padding: 15px;   
       margin: 10px 0px;   
       border: none;   
       cursor: pointer;   
}   

form 
{   
        border: 3px solid #f1f1f1;   
}   

input[type=text], input[type=password] 
{   
       width: 100%;   
       margin: 8px 0;  
       padding: 12px 20px;   
       display: inline-block;   
       border: 2px solid green;   
       box-sizing: border-box;   
}  

button:hover 
{   
       opacity: 0.6;   
}   
 
.container 
{   
       padding: 25px;   
       background-color: lightblue;  
} 

.links 
{   
       width: auto;   
       padding: 10px 18px;  
       margin: 10px 5px;  
}       
</style>   
</head>    
<body> 
<div class="container">
              <div class="row">
                     <div class="col">
                            <a href="index.html" id="home-page">Home Page</a>
                            <a href="TopicsMenu.html" id="veg-menu" style="margin-left: 10px;">Topics Menu</a>
                     </div>
              </div>
       </div>
       <h1>Topic</h1>

      
			  
			   <?php
			   
			  if (!empty($_GET["id"])) {
				  
				  ?>
				     <form action="" method="POST" enctype="multipart/form-data">  
       <div class="container">   
            <label>Name : </label>   
            <input type="text" placeholder="Enter Name" name="name" required>  
           
            <!-- <label>Fruit's Image </label>
            <input type="file" placeholder="Browse Image" name="image"> -->
            <button type="submit" name="submitMapper">Submit Mapper</button>    
        </div>   
    </form>     
				  
				  <?php
       $connection = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($connection,'db_name');
       if(isset($_POST['submitMapper']))
              {
                            // $image        = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                            $name     = $_POST['name'];
                         
                            $iid=$_GET['id'];

                            
                            
                            
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "db_name";

                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            // Check connection
                            if ($conn->connect_error) {
                                   die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "Update topics SET name='$name'  where id='$iid'";

                            if ($conn->query($sql) === TRUE) {
                                   echo "Record updated successfully";
                                   ?>
                                   <script>
                                       document.getElementById("home-page").href="../index.html";
                                       document.getElementById("veg-menu").href="../TopicsMenu.html";
                                   </script>
                                   <?php
                            } else {
                                   echo "Error updating record: " . $conn->error;
                                   ?>
                                   <script>
                                       document.getElementById("home-page").href="../index.html";
                                       document.getElementById("veg-menu").href="../TopicsMenu.html";
                                   </script>
                                   <?php
                            }

                            $conn->close();
														  
														  
														  
														  
												   }
         
							} else {  
							 
						

			   ?>
			   <table>
              <thead>
                     <tr>
                            <th> ID </th>
                            <th>Name</th>
                          
                            <!-- <th>Image</th> -->
                     </tr>
              </thead>
              <tbody>
                     <?php
                            $servername   = "localhost";
                            $username     = "root";
                            $password     = "";
                            $dbname       = "db_name";
 
                            // Creating connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
 
                            // Checking connection
                            if ($conn->connect_error)
                            {
                                   die("Connection failed:". $conn->connect_error);
                            }

                            $sql = "SELECT * FROM topics";
                            $result = $conn->query($sql);

                            if(!$result)
                            {
                                   die("Invalid Query:".$conn->connect_error);
                            }

                            //output data of each row
                            while($row = $result->fetch_assoc())
                            {
                                   echo "<tr>
                                          <td>" . $row["id"] . "</td>
                                          <td>" . $row["name"] . "</td>
                                          <td><a href='/fp3/UpdateTopic.php/?id=" . $row["id"] . "'>Update</a> </td>
                                          </tr>";
                            }
							
								}
                     ?>
              </tbody>
       </table>
</body>
</html>