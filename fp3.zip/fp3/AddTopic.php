<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> FruitMapperEntry </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
button 
{   
       background-color: #4CAF50;   
       width: 100%;  
       color: orange;   
       padding: 15px;   
       margin: 10px 0px;   
       border: none;   
       cursor: pointer;   
}   

form 
{   
        border: 3px solid #f1f1f1;   
}   

input[type=text], input[type=password] 
{   
       width: 100%;   
       margin: 8px 0;  
       padding: 12px 20px;   
       display: inline-block;   
       border: 2px solid green;   
       box-sizing: border-box;   
}  

button:hover 
{   
       opacity: 0.6;   
}   
 
.container 
{   
       padding: 25px;   
       background-color: lightblue;  
}   

.links 
{   
       width: auto;   
       padding: 10px 18px;  
       margin: 10px 5px;  
}     
</style>   
</head>    
<body>
 <div> 
       <button type="button" class="links"> <a href="index.html">HomePage</button>   
       <button type="button" class="links"><a href="UpdateTopic.php">Update Fruit Word Mapper</a></button>
       <button type="button" class="links"><a href="ViewTopics.php">View Fruit Word Mapper</a></button> 
       <button type="button" class="links"><a href="DeleteTopic.php">Delete From Fruit Word Mapper</a></button>
       
       <center> <h1> Add a Topic </h1> </center></div>
       <form action="" method="POST" enctype="multipart/form-data">  
       <div class="container">   
            <label>Name : </label>
            <input type="text" placeholder="Enter Name" name="name" required>
            <button type="submit" name="submitMapper">Add</button>    
        </div>   
    </form>     
</body>     
</html>

<?php
       $connection = mysqli_connect("localhost","root","");
       $db = mysqli_select_db($connection,'db_name');

       if(isset($_POST['submitMapper']))
       {
              // $image        = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
              $name     = $_POST['name'];

              $query        = "INSERT INTO `topics`(`name`) 
                               VALUES ('$name')";

              $query_run    = mysqli_query($connection,$query);

              if($query_run)
              {
                     echo '<script type="text/javascript"> alert("Data Inserted Succefully") </script>';
              }

              else
              {
                     echo '<script type="text/javascript"> alert("Data Insertion Failed") </script>';
              }
       }
?>