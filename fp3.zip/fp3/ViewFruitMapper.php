<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> FruitMapper </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
button 
{   
       background-color: #4CAF50;   
       width: 100%;  
       color: orange;   
       padding: 15px;   
       margin: 10px 0px;   
       border: none;   
       cursor: pointer;   
}   

form 
{   
        border: 3px solid #f1f1f1;   
}   

input[type=text], input[type=password] 
{   
       width: 100%;   
       margin: 8px 0;  
       padding: 12px 20px;   
       display: inline-block;   
       border: 2px solid green;   
       box-sizing: border-box;   
}  

button:hover 
{   
       opacity: 0.6;   
}   
 
.container 
{   
       padding: 25px;   
       background-color: lightblue;  
} 

.links 
{   
       width: auto;   
       padding: 10px 18px;  
       margin: 10px 5px;  
}       
</style>   
</head>    
<body> 
       <div class="container">
              <div class="row">
                     <div class="col">
                            <a href="index.html">Home Page</a>
                            <a href="FruitsMenu.html" style="margin-left: 10px;">Fruits Menu</a>
                     </div>
              </div>
       </div>
       <h1>Fruits Word Mapper</h1>

       <table>
              <thead>
                     <tr>
                            <th> ID </th>
                            <th>Category</th>
                            <th>English Name</th>
                            <th>Hindi Name</th>
                            <th>Telugu Name</th>
                            <!-- <th>Image</th> -->
                     </tr>
              </thead>
              <tbody>
                     <?php
                            $servername   = "localhost";
                            $username     = "root";
                            $password     = "";
                            $dbname       = "db_name";
 
                            // Creating connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
 
                            // Checking connection
                            if ($conn->connect_error)
                            {
                                   die("Connection failed:". $conn->connect_error);
                            }

                            $sql = "SELECT * FROM fruitwordmapper where fruit = 1";
                            $result = $conn->query($sql);

                            if(!$result)
                            {
                                   die("Invalid Query:".$conn->connect_error);
                            }

                            //output data of each row
                            while($row = $result->fetch_assoc())
                            {
                                   echo "<tr>
                                          <td>" . $row["ID"] . "</td>
                                          <td>" . $row["Category"] . "</td>
                                          <td>" . $row["EnglishName"] . "</td>
                                          <td>" . $row["HindiName"] . "</td>
                                          <td>" . $row["TeluguName"] . "</td>
                                          
                                          </tr>";
                            }
                     ?>
              </tbody>
       </table>
</body>
</html>