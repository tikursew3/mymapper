<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> FruitMapper </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
button 
{   
       background-color: #4CAF50;   
       width: 100%;  
       color: orange;   
       padding: 15px;   
       margin: 10px 0px;   
       border: none;   
       cursor: pointer;   
}   

form 
{   
        border: 3px solid #f1f1f1;   
}   

input[type=text], input[type=password] , select
{   
       width: 100%;   
       margin: 8px 0;  
       padding: 12px 20px;   
       display: inline-block;   
       border: 2px solid green;   
       box-sizing: border-box;   
}  

button:hover 
{   
       opacity: 0.6;   
}   
 
.container 
{   
       padding: 25px;   
       background-color: lightblue;  
} 

.links 
{   
       width: auto;   
       padding: 10px 18px;  
       margin: 10px 5px;  
}       
</style>   
</head>    
<body> 

       <div class="container">
              <div class="row">
                     <div class="col">
                            <a href="index.html" id="home-page">Home Page</a>
                            <a href="VegetablesMenu.html" id="veg-menu" style="margin-left: 10px;">Vegetables Menu</a>
                     </div>
              </div>
       </div>
       <h1>Vegetables Word Mapper</h1>

      
			  
			   <?php
			   
			  if (!empty($_GET["id"])) {
				  
				  ?>
				     <form action="" method="POST" enctype="multipart/form-data">  
       <div class="container">   
              <select name="category" id="" required>
                   <option value="">Select Topic</option>
                     <?php
                            $servername   = "localhost";
                            $username     = "root";
                            $password     = "";
                            $dbname       = "db_name";
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            $sql = "SELECT * FROM topics";
                            $result = $conn->query($sql);
                            while($row = $result->fetch_assoc())
                            {
                            ?>
                            <option value="<?php echo $row["name"]; ?>"><?php echo $row["name"]; ?></option>
                     <?php
                            }
                     ?>  
              </select>
            <label>English Name : </label>
            <input type="text" placeholder="Enter English Name" name="EnglishName" required>
            <label>Hindi Name : </label>   
            <input type="text" placeholder="Enter Hindi Name" name="HindiName" required>
            <label>Telugu Name : </label>   
            <input type="text" placeholder="Enter Telugu Name" name="TeluguName" required> 
            <!-- <label>Fruit's Image </label>
            <input type="file" placeholder="Browse Image" name="image"> -->
            <button type="submit" name="submitMapper">Submit Mapper</button>    
        </div>   
    </form>     
				  
				  <?php
       $connection = mysqli_connect("localhost","root","");
              $db = mysqli_select_db($connection,'db_name');
       if(isset($_POST['submitMapper']))
              {
                            // $image        = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                            $categoryy     = $_POST['category'];
                            $englishName  = $_POST['EnglishName'];
                            $hindiName    = $_POST['HindiName'];
                            $teluguName   = $_POST['TeluguName'];
                            $iid=$_GET['id'];

                            
                            
                            
                            $servername = "localhost";
                     $username = "root";
                            $password = "";
                            $dbname = "db_name";

                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            // Check connection
                            if ($conn->connect_error) {
                                   die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "Update fruitwordmapper SET Category='$categoryy' , EnglishName='$englishName',
                            HindiName='$hindiName', TeluguName='$teluguName' where ID='$iid'";

                            if ($conn->query($sql) === TRUE) {
                                   echo "Record updated successfully";
                                   ?>
                                   <script>
                                       document.getElementById("home-page").href="../index.html";
                                       document.getElementById("veg-menu").href="../VegetablesMenu.html";
                                   </script>
                                   <?php
                            } else {
                                ?>
                                <script>
                                    document.getElementById("home-page").href="../index.html";
                                    document.getElementById("veg-menu").href="../VegetablesMenu.html";
                                </script>
                                <?php
                                   echo "Error updating record: " . $conn->error;
                            }

                            $conn->close();
														  
														  
														  
														  
												   }
         
							} else {  
							 
						

			   ?>
			   <table>
              <thead>
                     <tr>
                            <th> ID </th>
                            <th>Category</th>
                            <th>English Name</th>
                            <th>Hindi Name</th>
                            <th>Telugu Name</th>
                            <!-- <th>Image</th> -->
                     </tr>
              </thead>
              <tbody>
                     <?php
                            $servername   = "localhost";
                            $username     = "root";
                            $password     = "";
                            $dbname       = "db_name";
 
                            // Creating connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
 
                            // Checking connection
                            if ($conn->connect_error)
                            {
                                   die("Connection failed:". $conn->connect_error);
                            }

                            $sql = "SELECT * FROM fruitwordmapper where fruit = 0";
                            $result = $conn->query($sql);

                            if(!$result)
                            {
                                   die("Invalid Query:".$conn->connect_error);
                            }

                            //output data of each row
                            while($row = $result->fetch_assoc())
                            {
                                   echo "<tr>
                                          <td>" . $row["ID"] . "</td>
                                          <td>" . $row["Category"] . "</td>
                                          <td>" . $row["EnglishName"] . "</td>
                                          <td>" . $row["HindiName"] . "</td>
                                          <td>" . $row["TeluguName"] . "</td>
                                          <td><a href='/fp3/UpdateVegetableMapper.php/?id=" . $row["ID"] . "'>Update</a> </td>
                                          </tr>";
                            }
							
								}
                     ?>
              </tbody>
       </table>
</body>
</html>