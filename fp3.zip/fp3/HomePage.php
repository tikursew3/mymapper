<?php
if(isset($_POST["login"])){
       // echo "<script>
       //               alert('logging in');
       //        </script>";
       include('session-start.php');
       // if(session_status() === PHP_SESSION_ACTIVE){
       //        echo "actiev";
       // }
       $servername   = "localhost";
       $username     = "root";
       $password     = "";
       $dbname       = "db_name";

       // Creating connection
       $conn = new mysqli($servername, $username, $password, $dbname);

       $username = $_POST["name"];
       $password = $_POST["pass"];
       $sql = "select * from login where name = '$username' AND password = '$password'";
       $result = mysqli_query($conn,$sql);
       // var_dump($result);
       // var_dump($sql);
       if(mysqli_num_rows($result) > 0){
              ?>
              <!DOCTYPE html>   
              <html>   
              <head>  
              <meta name="viewport" content="width=device-width, initial-scale=1">  
              <title> Home Page </title>  
              <style>   
              Body {  
              font-family: Calibri, Helvetica, sans-serif;  
              background-color: pink;  
              }  
              button 
              {   
                     background-color: #4CAF50;   
                     width: 100%;  
                     color: orange;   
                     padding: 15px;   
                     margin: 10px 0px;   
                     border: none;   
                     cursor: pointer;   
              }   

              form 
              {   
                     border: 3px solid #f1f1f1;   
              }   

              input[type=text], input[type=password] 
              {   
                     width: 100%;   
                     margin: 8px 0;  
                     padding: 12px 20px;   
                     display: inline-block;   
                     border: 2px solid green;   
                     box-sizing: border-box;   
              }  

              button:hover 
              {   
                     opacity: 0.6;   
              }   
              
              .container 
              {   
                     padding: 25px;   
                     background-color: lightblue;  
              }   
              </style>   
              </head>    
              <body> 
              <br>   
              <center> <h1> Main Menu </h1> </center>   
              <br>
              <br>
              <form>  
                     <div class="container">   
                            <button type="button"><a href="FruitsMenu.html">Click Here For Fruits Word Mapper</a></button>   
                            <button type="button"><a href="VegetablesMenu.html">Click Here For Vegetable Word Mapper</a></button> 
                            <button type="button"><a href="TopicsMenu.html">Click Here For Managing Topics</a></button> 
                     </div>   
              </form>     
              </body>     
              </html>

<?php
       }
       // else{
       //        echo "<script>
       //               alert('wrong credentials');
       //        </script>";
       // }   
}

?>